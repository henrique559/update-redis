#include "jemalloc/internal/jemalloc_preamble.h"
#include "jemalloc/internal/jemalloc_internal_includes.h"

ph_gen(, edata_avail, edata_t, avail_link,
    edata_esnead_comp)
ph_gen(, edata_heap, edata_t, heap_link, edata_snad_comp)
