#!/bin/tcsh

su -m root -c 'pkg install -y git'
